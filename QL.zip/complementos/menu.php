<nav class="navbar navbar-dark bg-dark fixed-left">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#" title="Equipos">
        <i class="fas fa-users"></i>
        <span>Equipos</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#" title="Jugadores">
        <i class="fas fa-user"></i>
        <span>Jugadores</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#" title="Partidos">
        <i class="fas fa-futbol"></i>
        <span>Partidos</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#" title="Goles">
        <i class="fas fa-futbol"></i>
        <span>Goles</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#" title="Cartas Amarillas">
        <i class="fas fa-square"></i>
        <span>Cartas Amarillas</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#" title="Cartas Rojas">
        <i class="fas fa-square red"></i>
        <span>Cartas Rojas</span>
      </a>
    </li>
  </ul>
</nav>




